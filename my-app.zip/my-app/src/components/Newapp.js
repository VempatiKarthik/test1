import React from "react"
import './Newapp.css';

const Welcome = () => {
    return (
        <div>
        <div className="header">
        
            <h1>Hello World</h1>
        </div>

        <div className="footer">
            <h1>Footer</h1>
        </div>
        </div>
    );
}

export default Welcome;