import './App.css';
import Welcome from './components/Newapp';

function App() {
  return (
    <div className="App">
      
      <Welcome />
    </div>
  )
}

export default App;
